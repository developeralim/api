<?php
      $api_endpoint = 'http://localhost/frontend/api/v1/api.php';
      $api_key      = '39802830831bed188884e193d8465226frontendapis.com';

      $ch = curl_init(); //curl initialize
      
      curl_setopt($ch,CURLOPT_URL,$api_endpoint);
      curl_setopt($ch,CURLOPT_TIMEOUT,30);
      curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,30);
      curl_setopt($ch,CURLOPT_POST,1);
      curl_setopt($ch,CURLOPT_POSTFIELDS,[]);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
      curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
      curl_setopt($ch, CURLOPT_HTTPHEADER,[
            "Authorization: Bearer $api_key",'Accept:application/json'
      ]);
      
      $content = curl_exec($ch);
      $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

      if ( $code == 200 && ! curl_errno($ch) ) {
            echo '<pre>';
            print_r(json_decode($content,true));
      } else {
            echo curl_errno($ch);
      }

      curl_close( $ch);
?>


<!doctype html>
<html lang="en">

<head>
      <title>Title</title>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <!-- Bootstrap CSS v5.2.1 -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

</head>

<body>
      <nav class="navbar navbar-expand-sm navbar-light bg-primary">
            <div class="container">
                  <a class="navbar-brand" href="#">primary</a>
                  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarID"
                        aria-controls="navbarID" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarID">
                        <div class="navbar-nav">
                              <a class="nav-link active" aria-current="page" href="#">Home</a>

                        </div>
                  </div>
            </div>
      </nav>

      <div class="container">

      </div>
      <!-- Bootstrap JavaScript Libraries -->
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
            integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
      </script>

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
            integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
      </script>
</body>

</html>