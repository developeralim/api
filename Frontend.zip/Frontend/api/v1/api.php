<?php

      //we want to allow only POST,PUT AND DELTE Reuest request
      header('Access-Control-Request-Method: POST,PUT,DELETE');

      include_once dirname(__DIR__).'/../connections.php';

      /**
       * If the request is GET then show page not found message
       */
      if ( $_SERVER['REQUEST_METHOD']  === 'GET' ) {
            http_response_code(404);
            echo '<h1>404 - Page Not Found</h1>';
            exit();
      }
      

      /**
       * Check if it is post method
       */
      if ( $_SERVER['REQUEST_METHOD'] === 'POST' ) {
           
            $api_key = getallheaders()['Authorization'] ?? '';
            
            if ( ! $api_key ) {
                  echo json_encode([
                        'code'    => 400,
                        'message' => "Bad Request",
                        'data'    => [] 
                  ]);

                  die();
            }
            
            $api_key = trim(str_replace('Bearer','',$api_key));

            $query = "SELECT * FROM user WHERE api_key=:api_key";

            $stmt = $conn->prepare($query);

            $status = $stmt->execute([
                  ':api_key' => $api_key
            ]);

            if ( $status ) {
                  $result = $stmt->fetch(PDO::FETCH_ASSOC);

                  if ( empty($result) ) {
                        echo json_encode([
                              'code'    => 401,
                              'message' => "Unautheticated",
                              'data'    => [] 
                        ]);
      
                        die();
                  }

                  /**
                   * So far user is autheticated and appropriate for giving data to user
                   */

                  $stmt = $conn->prepare("SELECT * FROM books");
                  $stmt->execute();

                  $result = $stmt->fetch(PDO::FETCH_ASSOC);

                  echo json_encode([
                        'code'    => 200,
                        'message' => "Authenticated",
                        'data'    => $result
                  ]);

                  die();
                  
            }

      }