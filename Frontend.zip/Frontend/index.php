<?php 
    session_start();
    
    if ( 
        ! isset($_SESSION['ACCESS_TOKEN']) && ! isset($_SESSION['ID']) && ! isset($_SESSION['USER_NAME'])
    ) {
        header('location:http://localhost/frontend/login.php');
    } 

    

?>

<!doctype html>
<html lang="en">

<head>
      <title>Title</title>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <!-- Bootstrap CSS v5.2.1 -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

      <link rel="stylesheet" href="./assets/css/style.css">
</head>

<body>

      <div class="header">
            <nav class="navbar navbar-expand-sm navbar-light bg-light">
                  <div class="container">
                        <a class="navbar-brand" href="#">LOGO</a>
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarID"
                              aria-controls="navbarID" aria-expanded="false" aria-label="Toggle navigation">
                              <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarID">
                              <div class="navbar-nav">
                                    <a class="nav-link active" aria-current="page" href="#">Home</a>
                              </div>

                              <div class="user">
                                    <strong><?=$_SESSION['USER_NAME'] ?? '';?></strong>
                                    <a href="logout.php" class="btn btn-primary btn-sm">Logout</a>
                                    <!-- Button trigger modal -->
                                    <button type="button" class="btn btn-primary btn-sm mx-2" data-bs-toggle="modal"
                                          data-bs-target="#exampleModal">
                                          api key
                                    </button>

                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal" tabindex="-1"
                                          aria-labelledby="exampleModalLabel" aria-hidden="true">
                                          <div class="modal-dialog modal-lg">
                                                <div class="modal-content">
                                                      <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Your API KEY
                                                            </h5>
                                                            <button type="button" class="btn-close"
                                                                  data-bs-dismiss="modal" aria-label="Close"></button>
                                                      </div>
                                                      <div class="modal-body">
                                                            <strong>
                                                                  <?=$_SESSION['API_KEY'] ?? ''?>
                                                            </strong>
                                                      </div>
                                                      <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                  data-bs-dismiss="modal">Close</button>
                                                      </div>
                                                </div>
                                          </div>
                                    </div>

                              </div>
                        </div>
                  </div>
            </nav>
      </div>

      <div class="container">

      </div>

      <!-- Bootstrap JavaScript Libraries -->
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
            integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
      </script>

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
            integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
      </script>

      <script src="./assets/js/index.js"></script>
</body>

</html>