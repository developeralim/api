<?php

      session_start();
      
      include __DIR__.'/connections.php';

      $query = "UPDATE user SET access_token = :access_token WHERE id = :id";

      $stmt = $conn->prepare($query);
     
      $status = $stmt->execute([
            ':access_token' => '',
            ':id'           => $_SESSION['ID']
      ]);


      if ( $status ) {
            
            unset($_SESSION['ID']);
            unset($_SESSION['USER_NAME']);
            unset($_SESSION['ACCESS_TOKEN']);

            header('location:http://localhost/frontend/login.php');

      } else {
            header('location:http://localhost/frontend');
      }

      