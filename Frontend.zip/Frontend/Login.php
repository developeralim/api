<?php
      include __DIR__.'/connections.php';

      $message = '';
      $class   = "alert-danger";

      if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) 
      {
            extract($_POST);

            // validation before inserting to dabase
            $email = htmlspecialchars(strip_tags($email),ENT_QUOTES);
            $password = htmlspecialchars(($password),ENT_QUOTES);

            $query = "SELECT * FROM user WHERE user_email = :user_email";
            
            $stmt = $conn->prepare($query);

            if ( $stmt ) {

                  $stmt->execute([
                        ':user_email' => $email,
                  ]);

                  $result = $stmt->fetch(PDO::FETCH_ASSOC);

                  if( ! empty($result) ) {
                       
                        extract($result);

                        if( password_verify($password,$user_password) ) {
                              
                              $access_token = [
                                    'access_token' => hash('md5','access_token')
                              ];

                              $stmt = $conn->prepare("UPDATE user SET access_token = :access_token WHERE id=:id");

                              $status = $stmt->execute([
                                    ':access_token' => $access_token['access_token'],
                                    ':id'           => $id
                              ]);

                              if ( $status ) {
                                    session_start();
                                    $_SESSION['USER_NAME']        = $user_name;
                                    $_SESSION['ID']               = $id;
                                    $_SESSION['ACCESS_TOKEN']     = $access_token['access_token'];
                                    $_SESSION['API_KEY']          = $api_key;
                              }

                              header('location:http://localhost/frontend/');

                        } else {
                              $message = "Either password or email is wrong";
                              $class   = 'alert-danger';
                        }

                  } else {
                        $message = "Invalid Email Address";
                        $class   = 'alert-danger';
                  }

            } else {
                  $message = "Something wrong in your SQL query";
                  $class   = 'alert-danger';
            }

            // $stmt = $conn->prepare($query);

            // try {
            //       $stmt->execute([
            //             ':name'     => $name,
            //             ':email'    => $email,
            //             ':password' => password_hash($password,PASSWORD_BCRYPT),
            //       ]);

            //       $message = 'User Added';
            //       $class   = 'alert-success';

            // } catch (\PDOException  $th) {
            //      $message = $th->errorInfo[2];
            // }

      }

?>


<!doctype html>
<html lang="en">

<head>
      <title>Title</title>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <!-- Bootstrap CSS v5.2.1 -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
      <link rel="stylesheet" href="./assets/css/style.css">
</head>

<body>
      <div class="container">
            <form method="POST">
                  <div class="container">
                        <label for="email"><b>Email</b></label>
                        <input type="email" placeholder="Enter Email" name="email" required>

                        <label for="psw"><b>Password</b></label>
                        <input type="password" placeholder="Enter Password" name="password" required>
                        <button type="submit">Login</button>
                  </div>
            </form>
            <?php
                  if ( $message ) {
                        echo  "<p class='alert $class'>$message</p>";
                  }
            ?>
      </div>
      <!-- Bootstrap JavaScript Libraries -->
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
            integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
      </script>

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
            integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
      </script>
      <script src="./assets/js/index.js"></script>
</body>

</html>