<?php
      include __DIR__.'/connections.php';

      $message = '';
      $class   = "alert-danger";

      if ( $_SERVER['REQUEST_METHOD'] == 'POST' ) 
      {
            extract($_POST);

            // validation before inserting to dabase
            $name = htmlspecialchars(strip_tags($name),ENT_QUOTES);
            $email = htmlspecialchars(strip_tags($email),ENT_QUOTES);
            $password = htmlspecialchars(($password),ENT_QUOTES);

            $query = "INSERT INTO user (user_name,user_email,user_password,api_key) VALUES(:name,:email,:password,:api_key)";

            $stmt = $conn->prepare($query);

            try {
                  $stmt->execute([
                        ':name'     => $name,
                        ':email'    => $email,
                        ':password' => password_hash($password,PASSWORD_BCRYPT),
                        ':api_key'  => md5('api_key').'frontendapis.com',
                  ]);

                  $message = 'User Added';
                  $class   = 'alert-success';

            } catch (\PDOException  $th) {
                 $message = $th->errorInfo[2];
            }

      }

?>



<!doctype html>
<html lang="en">

<head>
      <title>Title</title>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <!-- Bootstrap CSS v5.2.1 -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
            integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">

      <link rel="stylesheet" href="./assets/css/style.css">
</head>

<body>
      <div class="container">
            <form method="POST" style="border:1px solid #ccc">
                  <div class="container">
                        <h1>Sign Up</h1>
                        <p>Please fill in this form to create an account.</p>
                        <hr>

                        <div class="form-group">
                              <label for="name"><b>Name</b></label>
                              <input type="text" placeholder="Enter Your Name" name="name" required>
                        </div>
                        <div class="form-group">
                              <label for="email"><b>Email</b></label>
                              <input type="email" placeholder="Enter email" name="email" id="email" required>
                        </div>

                        <div class="form-group">
                              <label for="psw"><b>Password</b></label>
                              <input type="password" placeholder="Enter Password" name="password" id="psw" required>
                        </div>

                        <div class="clearfix">
                              <button type="submit" class="signupbtn w-100">Sign Up</button>
                        </div>
                  </div>
                  <?php
                        if ( $message ) {
                              echo  "<p class='alert $class'>$message</p>";
                        }
                  ?>
            </form>
      </div>
      <!-- Bootstrap JavaScript Libraries -->
      <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
            integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous">
      </script>

      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.min.js"
            integrity="sha384-7VPbUDkoPSGFnVtYi0QogXtr74QeVeeIs99Qfg5YCF+TidwNdjvaKZX19NZ/e6oz" crossorigin="anonymous">
      </script>

      <script src="./assets/js/index.js"></script>
</body>

</html>